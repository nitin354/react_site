import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import Swal from "sweetalert2";

export default class Register extends Component {

  constructor() {
    super();
    this.state = {
      name:"",email:"",password:""
    }
}

 swalalert = (type,Message) => {  
  Swal.fire({  
    title: 'Success',  
    type: type,  
    text: Message 
  });  
}  
userregister = async () => {

   console.log("Left");
 
  const requestOptions = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(this.state)
};
const response = await fetch('http://localhost:8000/api/register', requestOptions);
const data = await response.json();
//this.setState({ postId: data.id });

   console.log(data)
   localStorage.setItem("user_info",JSON.stringify(data));
   this.state = {
    name:"",email:"",password:""
  }
   this.swalalert("success","Registered Successfully");

}

onInputchange = (event)=> {
  
  this.setState({
    [event.target.name]: event.target.value
  });
}

  render() {
    let {name,email,password} = this.state
    return (
      <div><div className='container'>
                   
      <div className="row ">
      <div className="col-md-4 "></div>
      
          <div className="col-md-4 my-5">
          <h1>Register</h1>
             <div className=" form-floating mb-3">
                  <input type="text" value={name} name="name" class="form-control" onChange={this.onInputchange} id="floatingname" placeholder="Enter Name" />
                  <label htmlFor="floatingname">Name</label>
              </div>
              <div className=" form-floating mb-3">
                  <input type="email" name="email" value={email} class="form-control" onChange={this.onInputchange} id="floatingInput" placeholder="name@example.com" />
                  <label htmlFor="floatingInput">Email address</label>
              </div>
              <div className="form-floating">
                  <input type="password" name="password" value={password} class="form-control" onChange={this.onInputchange} id="floatingPassword" placeholder="Password" />
                  <label htmlFor="floatingPassword">Password</label>
              </div>
                <Link to="/Login">Login</Link>

              <button className='btn btn-primary btn-md my-3' onClick={this.userregister}>Register</button>
          </div>
          <div className="col-md-4 "></div>
      </div>
  </div></div>
    )
  }
}
