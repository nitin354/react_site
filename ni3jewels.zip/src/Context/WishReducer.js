import { API_URL } from "../Helper";
import { useEffect } from "react";

export const wishreducer = (state, action) => {
  const { wish } = state;
  let product;
  let index;
  let updatedQty;

  switch (action.type) {
    case "ADD_TO_WISH":
      let wishdta = { wish: [...wish, { ...action.payload}] };
      var wishdata = [...wish];

      if (!wishdata.includes(action.payload)) {
        wishdata.push({ ...action.payload, qty: 1 });
        localStorage.setItem("wish", JSON.stringify(wishdata));
        //setCartItems(array);
      }
      return wishdta;

    case "REMOVE_FROM_WISH":
      var wishr = state.wish.filter((c) =>
        c.product_id
          ? c.product_id !== action.payload.product_id
          : c.stock_no !== action.payload.stock_no
      );
      localStorage.setItem("wish", JSON.stringify(wishr));
      return {
        wish: state.wish.filter((c) =>
          c.product_id
            ? c.product_id !== action.payload.product_id
            : c.stock_no !== action.payload.stock_no
        )
       
      };


    default:
      return state;
  }
};
