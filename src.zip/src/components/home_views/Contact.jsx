
import React, { Component } from 'react'

import { Col, Container, Row } from "react-bootstrap";
import Iframe from "react-iframe";
import { makeStyles } from "@material-ui/core/styles";
import { Link } from 'react-router-dom'
import Swal from "sweetalert2";
import axios from 'axios';

const useStyles = makeStyles((theme) => ({
  root: {
    "& > *": {
      margin: theme.spacing(1),
      width: "25ch",
    },
  },
}));

export default class Contact extends Component{
 //this.useStyles();
 constructor() {
  super();
  this.state = {
    name:"",email:"",message:""
  }
}

swalalert = (type,Message) => {  
Swal.fire({  
  title: 'Success',  
  type: type,  
  text: Message 
});  
}  
userregister = async () => {

 console.log("Left");

const requestOptions = {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(this.state)
};
const response = await fetch('http://localhost:8000/api/contactus', requestOptions);
const data = await response.json();
//this.setState({ postId: data.id });

 console.log(data)
 this.state = {
  name:"",email:"",message:""
}
 this.swalalert("success","Contact us submitted successfully");

}

onInputchange = (event)=> {

this.setState({
  [event.target.name]: event.target.value
});
}

  render(){
    let {name,email,message} = this.state
  return (
    <div className="bj_contact">
      <div className="wrap-bread-crumb breadcrumb_collection2">
        <div className="text-center bg-breadcrumb">
          <div className="title-page">
            <h2 className="">Contact us</h2>
          </div>
          <div className="bread-crumb">
            <a href="/" title="Back to the frontpage">
              Home<i className="fa fa-angle-right" aria-hidden="true"></i>
            </a>
            <strong>Contact us</strong>
          </div>
        </div>
      </div>
      <Container>
        <Row>
          <Col md={12} className="bj_map clearfix">
            <Iframe
              url="https://www.google.com/maps/embed?pb=!4v1643349301850!6m8!1m7!1sYTHlp87DEA6iOPPnYy8Zhw!2m2!1d40.75713341019492!2d-73.97968993909187!3f211.59283!4f0!5f0.7820865974627469"
              width="100%"
              height="450px"
              id="myId"
              className="mapIframe"
              display="initial"
              position="relative"
            />
          </Col>
        </Row>
        <Row className="bj_info2">
          <Col md={6} className="bj_contact">
            <div className="bj_contact_content">
              <h3>Get In Touch With Us</h3>
              <p>
                Donec sed odio dui. Fusce dapibus, tellus ac cursuscommodo,
                tortor mauris condimentum nibh, ut fermentum massa justo.
              </p>
            </div>
            <div className="bj_contact_form">
            <div className='container'>
                   
                   <div className="row ">
                   
                   
                      
                       <h1>Register</h1>
                          <div className=" form-floating mb-3">
                               <input type="text" value={name} name="name" class="form-control" onChange={this.onInputchange} id="floatingname" placeholder="Enter Name" />
                               <label htmlFor="floatingname">Name</label>
                           </div>
                           <div className=" form-floating mb-3">
                               <input type="email" name="email" value={email} class="form-control" onChange={this.onInputchange} id="floatingInput" placeholder="name@example.com" />
                               <label htmlFor="floatingInput">Email address</label>
                           </div>
                           <div className="form-floating">
                               <textarea type="textarea" rows="5" name="message" value={message} class="form-control" onChange={this.onInputchange} id="floatingPassword" placeholder="Password" >
                               </textarea><label htmlFor="floatingPassword">Password</label>
                           </div>
                            
             
                           <button className='btn btn-primary btn-md my-3' onClick={this.userregister}>Register</button>
                      
                     
                   </div>
               </div>
            </div>
          </Col>

          <Col md={6} className="bj_info">
            <div className="box_find">
              <h3>Find Our Office</h3>
              <p>
                Praesent commodo cursus magna, vel scelerisque nisl consectetur
                et. Cras mattis consectetur purus sit amet fermentum. Sed
                posuere est at lobortis.
              </p>
              <div class="info_find">
                <p>
                  <img
                    src="https://baladna.belgiumwebnet.com/assets/images/headerimg/call.svg"
                    alt="Phone Call"
                    className="top_img"
                    width="20px"
                  ></img>
                  Call us on (877) 471-8005
                </p>
                <p>
                  <img
                    src="https://baladna.belgiumwebnet.com/assets/images/headerimg/call.svg"
                    alt="Phone Call"
                    className="top_img"
                    width="20px"
                  ></img>
                  Fax : (877) 471-8005
                </p>
                <p>
                  <img
                    src="https://baladna.belgiumwebnet.com/assets/images/headerimg/loaction_icon.svg"
                    alt="address"
                    className="top_img"
                    width="20px"
                  ></img>
                  Address : 4350 W Touhy Ave, Lincolnwood, IL 60712
                </p>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
  };
};

//export default Contact;
