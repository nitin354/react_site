import React, { useState, useEffect, useContext } from "react";
import { Card, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import { Cartstate } from ".././Context/cartcontext";
import { WishState} from ".././Context/Wishcontext";
import { API_URL } from "../Helper";
import Swal from "sweetalert2";
import RangeSlider from "react-bootstrap-range-slider";
import axios from "axios";
import loader_img from "../loader.gif";

export default function Product(props) {
  const {
    state: { cart, qty },
    dispatch,
  } = Cartstate();


  const {
    wishstate: { wish },
    wishdispatch,
  } = WishState();

  const [data, setData] = useState([]);
  const [offset, setOffset] = useState(0);
  const [pview, setView] = useState("grid");
  const [search, setSearch] = useState("");
  const [count, setCount] = useState(0);
  const [loader, setLoader] = useState(true);

  async function getDataProduct() {
    setLoader(true);
    let url = `${API_URL}product/productbycategory/${props.category}/${offset}`;

    axios.get(url).then((res) => {
      const parsedata = res.data;
         
      // if(offset>0){
      //   setData(data.concat(parsedata.postdata));
      // }else{
      //   setData(parsedata.postdata);

      // }
      offset>0?setData(data.concat(parsedata.postdata)):setData(parsedata.postdata);
      
      
      setCount(parsedata.count);
      setLoader(false);
      //this.setState({ persons });
    });
    //setData(data.concat(parsedata));
  }

  useEffect(() => {
    getDataProduct();
  }, [offset, pview, count]);

  function load(page) {
    setOffset(offset + 1);
  }

  return (
    <div className="container my-5">
      <h1>{props.cat_head ? props.cat_head : "Products"}</h1>
      <div className={`col-md-3 `}>
        <label className="mx-2" onClick={() => setView("grid")}>
          Grid <span className="navbar-toggler-icon"></span>
        </label>
        <label className="mx-2" onClick={() => setView("list")}>
          List <span className="navbar-toggler-icon"></span>
        </label>
      </div>
      <div className={`row ${pview}`}>
        {/* <input type="text" value={search} onChange={(e)=>setSearch(e.target.value)} className="form-control"  id="floatingname" placeholder="Search" /> */}
        {/* <label>Total record {count}</label> */}
        {loader == true ? (
          <img src={loader_img} style={{ height: "635px" }} />
        ) : (
          <label>Total record {count}</label>
        )}

        {loader == true ? (
          <img src={loader_img} style={{ height: "635px" }} />
        ) : (
          data &&
          data.map((product, index) => (
            <div
              key={index}
              className={pview == "grid" ? "col-md-3 my-2" : "col-md-12 my-2"}
            >
              <Card>
                <Card.Body>
                  <Link className="title_color" to={`/product/${product.slug}`}>
                    <Card.Img
                      variant="top"
                      className={pview == "grid" ? "" : "list_img"}
                      src={
                        product.url
                          ? product.url
                          : "https://dl2vs6wk2ewna.cloudfront.net/scrap/overnight/50853-E/50853-E.side.jpg"
                      }
                    />
                    <Card.Title className="danger title_color">
                      {product.name}
                    </Card.Title>
                    <Card.Title className="danger title_color ">
                      ${product.sale_price}
                    </Card.Title>
                  </Link>
                  {/* <Card.Text>
                          Some quick example text to build on the card title and make up the bulk of
                          the card's content.
                      </Card.Text> */}
                  
                  {wish.some((c) => c.product_id == product.product_id) ? (
                    <Button
                      className={`bg_black btn-danger ${
                        pview == "grid" ? "" : "list_add_cart_btn"
                      }`}
                      onClick={() =>
                        wishdispatch({
                          type: "REMOVE_FROM_WISH",
                          payload: product
                          
                        })
                      }
                    >
                      Remove From Wishlist
                    </Button>
                  ) : (
                    <Button
                      className={`bg_black btn-dark ${
                        pview == "grid" ? "" : "list_add_cart_btn"
                      }`}
                      onClick={() =>
                        wishdispatch({
                          type: "ADD_TO_WISH",
                          payload: product
                        })
                      }
                    >
                      Add To Wishlist
                    </Button>
                  )}




                  {cart.some((p) => p.product_id == product.product_id) ? (
                    <Button
                      className={`bg_black btn-danger ${
                        pview == "grid" ? "" : "list_add_cart_btn"
                      }`}
                      onClick={() =>
                        dispatch({
                          type: "REMOVE_FROM_CART",
                          payload: product,
                          qty: 0,
                        })
                      }
                    >
                      Remove From Cart
                    </Button>
                  ) : (
                    <Button
                      className={`bg_black btn-dark ${
                        pview == "grid" ? "" : "list_add_cart_btn"
                      }`}
                      onClick={() =>
                        dispatch({
                          type: "ADD_TO_CART",
                          payload: product,
                          totalPrice: product.sale_price,
                          qty: 1,
                        })
                      }
                    >
                      Add To Cart
                    </Button>
                  )}

                  {/* <Button className='bg_black btn-dark' onClick={(e) => addtocart(product)}>Add To Cart</Button> */}
                </Card.Body>
              </Card>
            </div>
          ))
        )}
      </div>

      {
        <div className="col-md-12 text-center my5">
          {count > data.length ? (
            <Button variant="dark" className="load_more" onClick={load}>
              Load More
            </Button>
          ) : (
            ""
          )}
        </div>
      }
    </div>
  );
}
