import { createContext,useReducer,useContext } from "react";
import { wishreducer } from "./WishReducer";

export const WishContext = createContext();


const WishContextProvider = (props) => {
    let wishd = JSON.parse(localStorage.getItem("wish"));

    const [wishstate,wishdispatch] = useReducer(wishreducer,{
        wish:wishd || []
    })

    return(
        <WishContext.Provider value={{ wishstate, wishdispatch }}>
          {props.children}
        </WishContext.Provider>
    )
}

export default WishContextProvider;

export const WishState= () => {

    return useContext(WishContext);

}