import {React, useEffect,useState} from 'react'
import { Carousel } from 'react-bootstrap'

function Home() {

  const [banner, setBanner] = useState([])

  let url = `https://malak.demobw.com/webapi/api/home/slider`;
 
  async function getbannerData() {
      const response = await fetch(url);
      const data = await response.json();
      console.log(data.data)
      setBanner(data.data) ;
    }

  useEffect(() => {
    getbannerData();
  }, [])



  return (
    <div>  
    <Carousel >
{
          banner.length>0 ?banner &&
          banner.map((product, index) => (
           
                 <Carousel.Item key={index} interval={1000}>
                    <img
                      className="d-block w-100"
                      src={
                        product.image
                          ? product.image
                          : "https://dl2vs6wk2ewna.cloudfront.net/scrap/overnight/50853-E/50853-E.side.jpg"
                      }
                      alt="First slide"
                    />
                    {/* <Carousel.Caption>
                      <h3>First slide label</h3>
                      <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                    </Carousel.Caption> */}
                  </Carousel.Item>
 
  
            
          )):<h2 className="my-5" >No Products Found</h2>

                    }

     </Carousel>
    </div>  
  )

}

export default Home