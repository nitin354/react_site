import React from 'react';

export default function Login() {
  return <div>

      <h1>login</h1>
  </div>;
}
