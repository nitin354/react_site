import React from 'react';
import { Link } from 'react-router-dom';

export default function Header() {
  return (<div>
    <h1>Home</h1>
    <nav>
      <Link to="/">login</Link> |{" "}
      <Link to="/register">Register | </Link>
      <Link to="/addproduct">Add Product | </Link>
      <Link to="/updateproduct">Update Product</Link>
      
    </nav>
  </div>) 
}
