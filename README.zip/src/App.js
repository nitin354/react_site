
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/Header';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Addproduct from './components/Addproduct';
import Updateproduct from './components/Updateproduct';

function App() {
  return (
    
  <div>
    <div>
      <BrowserRouter>
        
        <Header />        
        <Routes>
          <Route exact path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/addproduct" element={<Addproduct />} />
          <Route path="/updateproduct" element={<Updateproduct />} />
        </Routes>
       
      </BrowserRouter>
    </div>
  </div>
    
  );
}

export default App;
