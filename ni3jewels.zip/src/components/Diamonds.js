import React, { useState, useEffect, useContext } from "react";
import { Card, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import { API_URL } from "../Helper";
import Swal from "sweetalert2";
import { Cartstate } from ".././Context/cartcontext";

export default function Diamonds(props) {
  const {
    state: { cart, qty },
    dispatch,
  } = Cartstate();
  const [data, setData] = useState([]);
  const [offset, setOffset] = useState(0);
  const [dshape, setShape] = useState(localStorage.getItem("shape")?JSON.parse(localStorage.getItem("shape")):"");
  const [count,setCount] = useState(0)
  async function getDataDiamonds(shape) {
    setShape(shape);
    setOffset(0);
    //let url = `${API_URL}product/diamondbycategory/${offset}/${shape}`;
    let url = `${API_URL}product/diamondbycategory/0/${shape}`;
    let data2 = await fetch(url);
    let parsedata = await data2.json();
    setData(parsedata.postdata);
    setCount(parsedata.count)
  }

  useEffect(async () => {

    let url = `${API_URL}product/diamondbycategory/${offset}/${dshape}`;
    let data2 = await fetch(url);
    let parsedata = await data2.json();

    if (dshape.length > 0) {
      if (offset > 0) {
        setData(data.concat(parsedata.postdata));
        
      } else {
        setData(parsedata.postdata);
        setCount(parsedata.count)
      }
    } else {
      if (offset > 0) {
        setData(data.concat(parsedata.postdata));
      } else {
        console.log(parsedata);
        setData(parsedata.postdata);
        setCount(parsedata.count)
      }
    }

    localStorage.setItem("shape",JSON.stringify(dshape))
  }, [offset, dshape]);

  function load() {
    setOffset(offset + 1);
  }

  return (
    <div className="container my-5">
      <h1>{props.cat_head ? props.cat_head : "Products"}</h1>
      <div className="row">
        <div>
          <div className="d_box100 only-desktop  col-sm-12 col-md-12 col-lg-12 col-xs-12 no-padding1 jwel_pd">
            <label 
              onClick={() => {
                getDataDiamonds(dshape != "Round" ? "Round" : "");
              }}
            >
              <img
                src="https://greendia.belgiumwebnet.com/assets/images/gems_img/icon/round.png"
                alt="round"
                className={"img-size1 "+ (dshape == "Round"?"shape_active":"")}
              />
            </label>

            <label
              onClick={() => {
                getDataDiamonds(dshape != "Princess" ? "Princess" : "");
              }}
            >
              <img
                src="https://greendia.belgiumwebnet.com/assets/images/gems_img/icon/princess.png"
                alt="princess"
                className={"img-size1 "+ (dshape == "Princess"?"shape_active":"")}
              />
            </label>

            <label
              onClick={() => {
                getDataDiamonds(dshape != "Cushion" ? "Cushion" : "");
              }}
            >
              <img
                src="https://greendia.belgiumwebnet.com/assets/images/gems_img/icon/cushion.png"
                alt="cushion"
                className={"img-size1 "+ (dshape == "Cushion"?"shape_active":"")}
              />
            </label>

            <label
              onClick={() => {
                getDataDiamonds(dshape != "Oval" ? "Oval" : "");
              }}
            >
              <img
                src="https://greendia.belgiumwebnet.com/assets/images/gems_img/icon/oval.png"
                alt="oval"
                className={"img-size1 "+ (dshape == "Oval"?"shape_active":"")}
              />
            </label>

            <label
              onClick={() => {
                getDataDiamonds(dshape != "Emerald" ? "Emerald" : "");
              }}
            >
              <img
                src="https://greendia.belgiumwebnet.com/assets/images/gems_img/icon/emerald.png"
                alt="emerald"
                className={"img-size1 "+ (dshape == "Emerald"?"shape_active":"")}
              />
            </label>

            <label
              onClick={() => {
                getDataDiamonds(dshape != "Marquise" ? "Marquise" : "");
              }}
            >
              <img
                src="https://greendia.belgiumwebnet.com/assets/images/gems_img/icon/marquise.png"
                alt="marquise"
                className={"img-size1 "+ (dshape == "Marquise"?"shape_active":"")}
              />
            </label>

            <label
              onClick={() => {
                getDataDiamonds(dshape != "Pear" ? "Pear" : "");
              }}
            >
              <img
                src="https://greendia.belgiumwebnet.com/assets/images/gems_img/icon/pear.png"
                alt="pear"
                className={"img-size1 "+ (dshape == "Pear"?"shape_active":"")}
              />
            </label>
          </div>
        </div>
        <label>Total record {count}</label>
        {data &&
          data.map((product, index) => (
            <div key={index} className="col-md-3 my-2">
              <Card style={{ width: "18rem" }}>
                <Card.Body>
                  <Link className="title_color" to={`/product/${product.slug}`}>
                    <Card.Img
                      variant="top"
                      src={
                        product.imagelink
                          ? product.imagelink
                          : "https://dnalinks.in/T8893/still.jpg"
                      }
                    />
                    <Card.Title className="danger title_color my-3">
                      {product.weight +
                        " Carat " +
                        product.shape +
                        " Cut  DIAMOND"}
                    </Card.Title>
                    <Card.Title className="danger title_color ">
                      ${product.actual_price}
                    </Card.Title>
                  </Link>

                  {/* <Button
                    className="bg_black btn-dark"
                    onClick={(e) => dispatch({type:"ADD_TO_CART",payload:product})}
                  >
                    Add To Cart
                  </Button> */}
                  {cart.some((p) => p.stock_no == product.stock_no) ? (
                    <Button
                      className="bg_black btn-danger"
                      onClick={() =>
                        dispatch({
                          type: "REMOVE_FROM_CART",
                          payload: product,
                          qty: 0,
                        })
                      }
                    >
                      Remove From Cart
                    </Button>
                  ) : (
                    <Button
                      className="bg_black btn-dark"
                      onClick={() =>
                        dispatch({
                          type: "ADD_TO_CART",
                          payload: product,
                          totalPrice: product.sale_price,
                          qty: 1,
                        })
                      }
                    >
                      Add To Cart
                    </Button>
                  )}
                </Card.Body>
              </Card>
            </div>
          ))}
      </div>

            {
                <div className="col-md-12 text-center my5">
                { count > data.length ? <Button variant="dark" className="load_more" onClick={load}>Load More</Button>:""}
                </div>
            }
      {/* <div className="col-md-12 text-center my5">
  
        <Button variant="dark" className="load_more" onClick={load}>
          Load More
        </Button>
      </div> */}
    </div>
  );
}
