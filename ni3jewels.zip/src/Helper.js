
  
  
  
  import { cartContext } from '../src/Context/cartcontext';
  import React ,{ useContext } from 'react';
  
 export function Addtocart(element){
     const [cart, setCart] = useContext(cartContext);
           if(!cart.includes(element)){
            setCart(cart =>[...cart,element]);
         }
   }

//export const API_URL = "https://ni3shop.000webhostapp.com/api/"

export const API_URL = "http://localhost/codeigniter/api/"
  