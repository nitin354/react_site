import React, { useContext, useEffect, useState } from "react";
import { Navbar, NavDropdown, Container, Nav, Dropdown } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { Cartstate } from "../Context/cartcontext";
//import { cartContext } from '../Context/cartcontext';

export default function Header(props) {
  const {
    state: { cart },
  } = Cartstate();
  // const [cart, setCart] = useContext(cartContext);
  let user_info = localStorage.getItem("user_info")
    ? JSON.parse(localStorage.getItem("user_info"))
    : "";
  const redirect = useNavigate();
  console.log(user_info.name);
  useEffect(() => {}, [cart]);

  function logout() {
    localStorage.setItem("user_info", "");
    redirect("/");
  }

  return (
    <div>
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Container>
          <Navbar.Brand>
            <Link to="/">Ni3 jewels</Link>
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="me-auto">
              <Link className="navbar-dark navbar-brand" to="/diamonds">
                Diamonds
              </Link>
              <Link className="navbar-dark navbar-brand" to="/engagement">
                Engagement
              </Link>
              <Link className="navbar-dark navbar-brand" to="/wedding">
                Wedding
              </Link>
            </Nav>
            {user_info ? (
              <NavDropdown
                id="nav-dropdown-dark-example"
                title={user_info.name.toUpperCase()}
                menuVariant="dark"
              >
                <NavDropdown.Item onClick={logout}>Logout</NavDropdown.Item>
              </NavDropdown>
            ) : (
              <Link className="navbar-dark navbar-brand" to="/login">
                Login
              </Link>
            )}

            <Link className="navbar-dark navbar-brand" to="/cart">
              Cart ({cart.length})
            </Link>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
}
