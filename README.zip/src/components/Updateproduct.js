import React from 'react';

export default function Updateproduct() {
  return <div><h1>Update Product</h1></div>;
}
