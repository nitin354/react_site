import React, { useState, useEffect, useContext } from "react";
import { Card, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import { Cartstate } from ".././Context/cartcontext";
import { WishState} from ".././Context/Wishcontext";
import { API_URL } from "../Helper";
import Swal from "sweetalert2";
import RangeSlider from "react-bootstrap-range-slider";
import axios from "axios";
import loader_img from "../loader.gif";

export default function Wishlist(props) {

  const {
    wishstate: { wish },
    wishdispatch,
  } = WishState();
//   const [loader, setLoader] = useState(true);
//   useEffect(() => {
//   }, [wish])
  
  return (
    <div className="container my-5">
      <h1>{props.cat_head ? props.cat_head : "Products"}</h1>
      <div className="row">
        {/* <input type="text" value={search} onChange={(e)=>setSearch(e.target.value)} className="form-control"  id="floatingname" placeholder="Search" /> */}
        {/* <label>Total record {count}</label> */}
    
        <label>Total record { wish.length}</label>
       {
          wish.length>0 ?wish &&
          wish.map((product, index) => (
            <div
              key={index}
              className="col-md-3 my-2"
            >
              <Card>
                <Card.Body>
                  <Link className="title_color" to={`/product/${product.slug}`}>
                    <Card.Img
                      variant="top"
                      src={
                        product.url
                          ? product.url
                          : "https://dl2vs6wk2ewna.cloudfront.net/scrap/overnight/50853-E/50853-E.side.jpg"
                      }
                    />
                    <Card.Title className="danger title_color">
                      {product.name}
                    </Card.Title>
                    <Card.Title className="danger title_color ">
                      ${product.sale_price}
                    </Card.Title>
                  </Link>
      
                     <Button
                      className="bg_black btn-danger"
                      onClick={() =>
                        wishdispatch({
                          type: "REMOVE_FROM_WISH",
                          payload: product
                        })
                      }
                    >
                      Remove From Wishlist
                    </Button>
                </Card.Body>
              </Card>
            </div>
          )):<h2 className="my-5" >No Products Found</h2>

                    }
       
      </div>

    
    </div>
  );
}
