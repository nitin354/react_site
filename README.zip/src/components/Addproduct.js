import React from 'react';

export default function Addproduct() {
  return <div><h1>Add product</h1></div>;
}
