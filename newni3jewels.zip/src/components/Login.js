import React, {  useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { API_URL } from "../Helper";
import axios from "axios";
import Swal from "sweetalert2";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const redirect = useNavigate();

  function swalalert(type, Message) {
    Swal.fire({
      type: type,
      text: Message,
    });
  }

  async function loginuser() {
    let item = { email, password };
    var parsedata = "";
    axios.post(`${API_URL}users/login`, item).then((res) => {
      parsedata = res.data;

      if (parsedata.status == false) {
        swalalert("danger", parsedata.message);
      } else {
        localStorage.setItem("user_info", JSON.stringify(parsedata.user_info));
        setEmail("");
        setPassword("");
        redirect("/");
      }

    });
  }

  return (
    <div>
      <div className="container">
        <div className="row ">
          <div className="col-md-4 "></div>

          <div className="col-md-4 my-5">
            <h1>Login</h1>
            <div className=" form-floating mb-3">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="form-control"
                id="floatingInput"
                placeholder="name@example.com"
              />
              <label htmlFor="floatingInput">Email address</label>
            </div>
            <div className="form-floating">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="form-control"
                id="floatingPassword"
                placeholder="Password"
              />
              <label htmlFor="floatingPassword">Password</label>
            </div>
            <Link to="/register">Register</Link>

            <button className="btn btn-primary btn-md my-3" onClick={loginuser}>
              Login
            </button>
          </div>
          <div className="col-md-4 "></div>
        </div>
      </div>
    </div>
  );
}
